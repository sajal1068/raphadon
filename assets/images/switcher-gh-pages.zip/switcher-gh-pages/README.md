# SWITCHER

[![GitHub Issues](https://img.shields.io/badge/contributions-welcome-brightgreen.svg?style=flat)](https://github.com/alikinvv/switcher/issues)  [![HitCount](http://hits.dwyl.com/alikinvv/switcher.svg)](http://hits.dwyl.com/alikinvv/switcher)  [![License](https://img.shields.io/badge/license-MIT-blue.svg)](https://opensource.org/licenses/MIT)  [![Donations Badge](https://yourdonation.rocks/images/badge.svg)](https://www.paypal.me/alikinvv)

Animated toggle switches based on jQuery, anime.js, CSS/CSS3, and Checkbox or Radio input.

:star: Star us on GitHub — it helps!

## [Live Demo](https://alikinvv.github.io/switcher/build)

![switcher](https://dribbble.s3.amazonaws.com/users/1773016/screenshots/6133760/3.gif?1551882952106)

[![Analytics](https://ga-beacon.appspot.com/UA-31485994-5/switcher-repo)](https://github.com/alikinvv/switcher)
